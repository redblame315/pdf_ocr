# type: ignore
from .sinc import py_sinc as sinc
