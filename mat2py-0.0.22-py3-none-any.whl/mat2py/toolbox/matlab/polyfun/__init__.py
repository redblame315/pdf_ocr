# type: ignore
from .inpolygon import inpolygon
