# type: ignore
from .linspace import py_linspace as linspace
