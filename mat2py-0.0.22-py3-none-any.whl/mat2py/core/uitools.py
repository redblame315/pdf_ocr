# type: ignore

__all__ = [
    "uigetpref",
    "hasuimode",
    "uicontainer",
    "helpdlg",
    "uigettool",
    "findfigs",
    "awtinvoke",
    "waitforbuttonpress",
    "popupstr",
    "uitab",
    "selectmoveresize",
    "uirestore",
    "ginput",
    "btnpress",
    "propedit",
    "addpref",
    "uitabgroup",
    "guidata",
    "winmenu",
    "warndlg",
    "uipushtool",
    "clipboard",
    "waitbar",
    "menu",
    "btnup",
    "uisetpref",
    "tipoftheday",
    "makemenu",
    "btnicon",
    "filemenufcn",
    "uitreenode",
    "wizard",
    "listfonts",
    "helpmenufcn",
    "uistack",
    "uisetfont",
    "uitree",
    "dragrect",
    "uiopen",
    "cshelp",
    "getpixelposition",
    "editmenufcn",
    "inspect",
    "uisetcolor",
    "uigettoolbar",
    "setpixelposition",
    "uigetmodemanager",
    "uitable",
    "waitfor",
    "desktopmenufcn",
    "uiload",
    "uigridcontainer",
    "rmpref",
    "listdlg",
    "uisave",
    "uiwait",
    "isactiveuimode",
    "awtcreate",
    "uipanel",
    "usejavacomponent",
    "fignamer",
    "figflag",
    "insertmenufcn",
    "align",
    "uitoggletool",
    "activateuimode",
    "uiundo",
    "viewmenufcn",
    "inputdlg",
    "allchild",
    "getpref",
    "uibuttongroup",
    "setstatus",
    "setptr",
    "ispref",
    "getptr",
    "setpref",
    "btngroup",
    "guihandles",
    "uimode",
    "dialog",
    "uiclearmode",
    "tabdlg",
    "errordlg",
    "uiresume",
    "uitoolbar",
    "movegui",
    "getstatus",
    "getuimode",
    "overobj",
    "btnresize",
    "icondisp",
    "javacomponent",
    "uisuspend",
    "msgbox",
    "uigetfile",
    "remapfig",
    "export2wsdlg",
    "uiputfile",
    "btndown",
    "textwrap",
    "uiflowcontainer",
    "menulabel",
    "questdlg",
    "uigetdir",
    "btnstate",
    "toolsmenufcn",
    "uitoolfactory",
]


def uigetpref(*args):
    raise NotImplementedError("uigetpref")


def hasuimode(*args):
    raise NotImplementedError("hasuimode")


def uicontainer(*args):
    raise NotImplementedError("uicontainer")


def helpdlg(*args):
    raise NotImplementedError("helpdlg")


def uigettool(*args):
    raise NotImplementedError("uigettool")


def findfigs(*args):
    raise NotImplementedError("findfigs")


def awtinvoke(*args):
    raise NotImplementedError("awtinvoke")


def waitforbuttonpress(*args):
    raise NotImplementedError("waitforbuttonpress")


def popupstr(*args):
    raise NotImplementedError("popupstr")


def uitab(*args):
    raise NotImplementedError("uitab")


def selectmoveresize(*args):
    raise NotImplementedError("selectmoveresize")


def uirestore(*args):
    raise NotImplementedError("uirestore")


def ginput(*args):
    raise NotImplementedError("ginput")


def btnpress(*args):
    raise NotImplementedError("btnpress")


def propedit(*args):
    raise NotImplementedError("propedit")


def addpref(*args):
    raise NotImplementedError("addpref")


def uitabgroup(*args):
    raise NotImplementedError("uitabgroup")


def guidata(*args):
    raise NotImplementedError("guidata")


def winmenu(*args):
    raise NotImplementedError("winmenu")


def warndlg(*args):
    raise NotImplementedError("warndlg")


def uipushtool(*args):
    raise NotImplementedError("uipushtool")


def clipboard(*args):
    raise NotImplementedError("clipboard")


def waitbar(*args):
    raise NotImplementedError("waitbar")


def menu(*args):
    raise NotImplementedError("menu")


def btnup(*args):
    raise NotImplementedError("btnup")


def uisetpref(*args):
    raise NotImplementedError("uisetpref")


def tipoftheday(*args):
    raise NotImplementedError("tipoftheday")


def makemenu(*args):
    raise NotImplementedError("makemenu")


def btnicon(*args):
    raise NotImplementedError("btnicon")


def filemenufcn(*args):
    raise NotImplementedError("filemenufcn")


def uitreenode(*args):
    raise NotImplementedError("uitreenode")


def wizard(*args):
    raise NotImplementedError("wizard")


def listfonts(*args):
    raise NotImplementedError("listfonts")


def helpmenufcn(*args):
    raise NotImplementedError("helpmenufcn")


def uistack(*args):
    raise NotImplementedError("uistack")


def uisetfont(*args):
    raise NotImplementedError("uisetfont")


def uitree(*args):
    raise NotImplementedError("uitree")


def dragrect(*args):
    raise NotImplementedError("dragrect")


def uiopen(*args):
    raise NotImplementedError("uiopen")


def cshelp(*args):
    raise NotImplementedError("cshelp")


def getpixelposition(*args):
    raise NotImplementedError("getpixelposition")


def editmenufcn(*args):
    raise NotImplementedError("editmenufcn")


def inspect(*args):
    raise NotImplementedError("inspect")


def uisetcolor(*args):
    raise NotImplementedError("uisetcolor")


def uigettoolbar(*args):
    raise NotImplementedError("uigettoolbar")


def setpixelposition(*args):
    raise NotImplementedError("setpixelposition")


def uigetmodemanager(*args):
    raise NotImplementedError("uigetmodemanager")


def uitable(*args):
    raise NotImplementedError("uitable")


def waitfor(*args):
    raise NotImplementedError("waitfor")


def desktopmenufcn(*args):
    raise NotImplementedError("desktopmenufcn")


def uiload(*args):
    raise NotImplementedError("uiload")


def uigridcontainer(*args):
    raise NotImplementedError("uigridcontainer")


def rmpref(*args):
    raise NotImplementedError("rmpref")


def listdlg(*args):
    raise NotImplementedError("listdlg")


def uisave(*args):
    raise NotImplementedError("uisave")


def uiwait(*args):
    raise NotImplementedError("uiwait")


def isactiveuimode(*args):
    raise NotImplementedError("isactiveuimode")


def awtcreate(*args):
    raise NotImplementedError("awtcreate")


def uipanel(*args):
    raise NotImplementedError("uipanel")


def usejavacomponent(*args):
    raise NotImplementedError("usejavacomponent")


def fignamer(*args):
    raise NotImplementedError("fignamer")


def figflag(*args):
    raise NotImplementedError("figflag")


def insertmenufcn(*args):
    raise NotImplementedError("insertmenufcn")


def align(*args):
    raise NotImplementedError("align")


def uitoggletool(*args):
    raise NotImplementedError("uitoggletool")


def activateuimode(*args):
    raise NotImplementedError("activateuimode")


def uiundo(*args):
    raise NotImplementedError("uiundo")


def viewmenufcn(*args):
    raise NotImplementedError("viewmenufcn")


def inputdlg(*args):
    raise NotImplementedError("inputdlg")


def allchild(*args):
    raise NotImplementedError("allchild")


def getpref(*args):
    raise NotImplementedError("getpref")


def uibuttongroup(*args):
    raise NotImplementedError("uibuttongroup")


def setstatus(*args):
    raise NotImplementedError("setstatus")


def setptr(*args):
    raise NotImplementedError("setptr")


def ispref(*args):
    raise NotImplementedError("ispref")


def getptr(*args):
    raise NotImplementedError("getptr")


def setpref(*args):
    raise NotImplementedError("setpref")


def btngroup(*args):
    raise NotImplementedError("btngroup")


def guihandles(*args):
    raise NotImplementedError("guihandles")


def uimode(*args):
    raise NotImplementedError("uimode")


def dialog(*args):
    raise NotImplementedError("dialog")


def uiclearmode(*args):
    raise NotImplementedError("uiclearmode")


def tabdlg(*args):
    raise NotImplementedError("tabdlg")


def errordlg(*args):
    raise NotImplementedError("errordlg")


def uiresume(*args):
    raise NotImplementedError("uiresume")


def uitoolbar(*args):
    raise NotImplementedError("uitoolbar")


def movegui(*args):
    raise NotImplementedError("movegui")


def getstatus(*args):
    raise NotImplementedError("getstatus")


def getuimode(*args):
    raise NotImplementedError("getuimode")


def overobj(*args):
    raise NotImplementedError("overobj")


def btnresize(*args):
    raise NotImplementedError("btnresize")


def icondisp(*args):
    raise NotImplementedError("icondisp")


def javacomponent(*args):
    raise NotImplementedError("javacomponent")


def uisuspend(*args):
    raise NotImplementedError("uisuspend")


def msgbox(*args):
    raise NotImplementedError("msgbox")


def uigetfile(*args):
    raise NotImplementedError("uigetfile")


def remapfig(*args):
    raise NotImplementedError("remapfig")


def export2wsdlg(*args):
    raise NotImplementedError("export2wsdlg")


def uiputfile(*args):
    raise NotImplementedError("uiputfile")


def btndown(*args):
    raise NotImplementedError("btndown")


def textwrap(*args):
    raise NotImplementedError("textwrap")


def uiflowcontainer(*args):
    raise NotImplementedError("uiflowcontainer")


def menulabel(*args):
    raise NotImplementedError("menulabel")


def questdlg(*args):
    raise NotImplementedError("questdlg")


def uigetdir(*args):
    raise NotImplementedError("uigetdir")


def btnstate(*args):
    raise NotImplementedError("btnstate")


def toolsmenufcn(*args):
    raise NotImplementedError("toolsmenufcn")


def uitoolfactory(*args):
    raise NotImplementedError("uitoolfactory")
