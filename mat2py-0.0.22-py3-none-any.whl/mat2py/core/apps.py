# type: ignore

__all__ = [
    "mlappinstallfinfo",
]


def mlappinstallfinfo(*args):
    raise NotImplementedError("mlappinstallfinfo")
