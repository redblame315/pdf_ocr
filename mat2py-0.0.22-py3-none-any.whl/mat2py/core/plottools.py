# type: ignore

__all__ = [
    "javaAddLsnrsToFigure",
    "plotbrowser",
    "adddatadlg",
    "makedisplaynames",
    "plottoolfunc",
    "enableplottoolbuttons",
    "propertyeditor",
    "showplottool",
    "getplotbrowserproptable",
    "plottools",
    "figurepalette",
    "javaGetHandles",
    "getplottool",
    "getfigurefordesktopclient",
    "addsubplot",
]


def javaAddLsnrsToFigure(*args):
    raise NotImplementedError("javaAddLsnrsToFigure")


def plotbrowser(*args):
    raise NotImplementedError("plotbrowser")


def adddatadlg(*args):
    raise NotImplementedError("adddatadlg")


def makedisplaynames(*args):
    raise NotImplementedError("makedisplaynames")


def plottoolfunc(*args):
    raise NotImplementedError("plottoolfunc")


def enableplottoolbuttons(*args):
    raise NotImplementedError("enableplottoolbuttons")


def propertyeditor(*args):
    raise NotImplementedError("propertyeditor")


def showplottool(*args):
    raise NotImplementedError("showplottool")


def getplotbrowserproptable(*args):
    raise NotImplementedError("getplotbrowserproptable")


def plottools(*args):
    raise NotImplementedError("plottools")


def figurepalette(*args):
    raise NotImplementedError("figurepalette")


def javaGetHandles(*args):
    raise NotImplementedError("javaGetHandles")


def getplottool(*args):
    raise NotImplementedError("getplottool")


def getfigurefordesktopclient(*args):
    raise NotImplementedError("getfigurefordesktopclient")


def addsubplot(*args):
    raise NotImplementedError("addsubplot")
