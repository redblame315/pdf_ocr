# type: ignore

__all__ = [
    "linkplotfunc",
    "brush",
    "linkdata",
]


def linkplotfunc(*args):
    raise NotImplementedError("linkplotfunc")


def brush(*args):
    raise NotImplementedError("brush")


def linkdata(*args):
    raise NotImplementedError("linkdata")
