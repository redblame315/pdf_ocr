# type: ignore

__all__ = [
    "mapreduce",
    "mapreducer",
    "gcmr",
]


def mapreduce(*args):
    raise NotImplementedError("mapreduce")


def mapreducer(*args):
    raise NotImplementedError("mapreducer")


def gcmr(*args):
    raise NotImplementedError("gcmr")
