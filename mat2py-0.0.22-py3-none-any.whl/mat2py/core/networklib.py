# type: ignore

__all__ = [
    "tcpclient",
]


def tcpclient(*args):
    raise NotImplementedError("tcpclient")
