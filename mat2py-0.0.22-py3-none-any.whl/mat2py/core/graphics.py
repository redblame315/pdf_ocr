# type: ignore

__all__ = [
    "close",
    "gobjects",
    "closereq",
    "vertexpicker",
    "findprinters",
    "figureheaderdlg",
    "pagesetupdlg",
    "savtoner",
    "axes",
    "hggetbehavior",
    "figcopytemplatelistener_legacy",
    "datacursormode",
    "hgaddbehavior",
    "uicontrol",
    "drawnow",
    "figcopytemplatelistener",
    "printprepare",
    "getappdata",
    "hgdisp",
    "figuredeletedlistener",
    "print",
    "linkaxes",
    "colornone",
    "copyobj",
    "copyoptionsfcn",
    "uicontextmenu",
    "printrestore",
    "gcbf",
    "shg",
    "resetplotview",
    "animatedline",
    "setappdata",
    "makehgtform",
    "hasbehavior",
    "capturescreen",
    "rmappdata",
    "printdlg",
    "parseparams",
    "bwcontr",
    "rectangle",
    "getcrosssection",
    "findall",
    "getframe",
    "openFigure",
    "line",
    "linkprop",
    "hggroup",
    "set",
    "newplot",
    "exportsetupdlg",
    "printtables",
    "ishandle",
    "dateTickPicker",
    "gcbo",
    "hgsave",
    "hgbehaviorfactory",
    "get",
    "handle2struct",
    "hgload",
    "reset",
    "ishold",
    "findobj",
    "refreshdata",
    "savefig",
    "refresh",
    "saveFigure",
    "uimenu",
    "ishghandle",
    "printtemplate",
    "cla",
    "hgclose",
    "getFigureToolManager",
    "nodither",
    "hggetdisp",
    "figure",
    "gcf",
    "isgraphics",
    "printjob",
    "figureToolbarCreateFcn",
    "hgfeval",
    "hgsetdisp",
    "noanimate",
    "axescheck",
    "light",
    "surface",
    "isappdata",
    "ancestor",
    "defaulterrorcallback",
    "opengl",
    "setprinttemplate",
    "regionpicker",
    "getprinttemplate",
    "datetickstr",
    "is2D",
    "clf",
    "groot",
    "printdmfile",
    "gca",
    "gco",
    "openfig",
    "hgtransform",
    "tex",
    "datachildren",
    "struct2handle",
    "orient",
    "hold",
    "graphicsversion",
    "printpreview",
]

from mat2py.common.logger import logger


def gobjects(*args):
    raise NotImplementedError("gobjects")


def closereq(*args):
    raise NotImplementedError("closereq")


def vertexpicker(*args):
    raise NotImplementedError("vertexpicker")


def findprinters(*args):
    raise NotImplementedError("findprinters")


def figureheaderdlg(*args):
    raise NotImplementedError("figureheaderdlg")


def pagesetupdlg(*args):
    raise NotImplementedError("pagesetupdlg")


def savtoner(*args):
    raise NotImplementedError("savtoner")


def axes(*args):
    raise NotImplementedError("axes")


def hggetbehavior(*args):
    raise NotImplementedError("hggetbehavior")


def figcopytemplatelistener_legacy(*args):
    raise NotImplementedError("figcopytemplatelistener_legacy")


def datacursormode(*args):
    raise NotImplementedError("datacursormode")


def hgaddbehavior(*args):
    raise NotImplementedError("hgaddbehavior")


def uicontrol(*args):
    raise NotImplementedError("uicontrol")


def drawnow(*args):
    raise NotImplementedError("drawnow")


def figcopytemplatelistener(*args):
    raise NotImplementedError("figcopytemplatelistener")


def printprepare(*args):
    raise NotImplementedError("printprepare")


def getappdata(*args):
    raise NotImplementedError("getappdata")


def hgdisp(*args):
    raise NotImplementedError("hgdisp")


def figuredeletedlistener(*args):
    raise NotImplementedError("figuredeletedlistener")


def print(*args):
    raise NotImplementedError("print")


def linkaxes(*args):
    raise NotImplementedError("linkaxes")


def colornone(*args):
    raise NotImplementedError("colornone")


def copyobj(*args):
    raise NotImplementedError("copyobj")


def copyoptionsfcn(*args):
    raise NotImplementedError("copyoptionsfcn")


def uicontextmenu(*args):
    raise NotImplementedError("uicontextmenu")


def printrestore(*args):
    raise NotImplementedError("printrestore")


def gcbf(*args):
    raise NotImplementedError("gcbf")


def shg():
    import matplotlib.pyplot as plt

    plt.show()


def resetplotview(*args):
    raise NotImplementedError("resetplotview")


def animatedline(*args):
    raise NotImplementedError("animatedline")


def setappdata(*args):
    raise NotImplementedError("setappdata")


def makehgtform(*args):
    raise NotImplementedError("makehgtform")


def hasbehavior(*args):
    raise NotImplementedError("hasbehavior")


def capturescreen(*args):
    raise NotImplementedError("capturescreen")


def rmappdata(*args):
    raise NotImplementedError("rmappdata")


def printdlg(*args):
    raise NotImplementedError("printdlg")


def parseparams(*args):
    raise NotImplementedError("parseparams")


def bwcontr(*args):
    raise NotImplementedError("bwcontr")


def rectangle(*args):
    raise NotImplementedError("rectangle")


def getcrosssection(*args):
    raise NotImplementedError("getcrosssection")


def findall(*args):
    raise NotImplementedError("findall")


def getframe(*args):
    raise NotImplementedError("getframe")


def openFigure(*args):
    raise NotImplementedError("openFigure")


def line(*args):
    raise NotImplementedError("line")


def linkprop(*args):
    raise NotImplementedError("linkprop")


def hggroup(*args):
    raise NotImplementedError("hggroup")


def set(*args):
    raise NotImplementedError("set")


def newplot(*args):
    raise NotImplementedError("newplot")


def exportsetupdlg(*args):
    raise NotImplementedError("exportsetupdlg")


def printtables(*args):
    raise NotImplementedError("printtables")


def ishandle(*args):
    raise NotImplementedError("ishandle")


def dateTickPicker(*args):
    raise NotImplementedError("dateTickPicker")


def gcbo(*args):
    raise NotImplementedError("gcbo")


def hgsave(*args):
    raise NotImplementedError("hgsave")


def hgbehaviorfactory(*args):
    raise NotImplementedError("hgbehaviorfactory")


def get(*args):
    raise NotImplementedError("get")


def handle2struct(*args):
    raise NotImplementedError("handle2struct")


def hgload(*args):
    raise NotImplementedError("hgload")


def reset(*args):
    raise NotImplementedError("reset")


def ishold(*args):
    raise NotImplementedError("ishold")


def findobj(*args):
    raise NotImplementedError("findobj")


def refreshdata(*args):
    raise NotImplementedError("refreshdata")


def savefig(*args):
    raise NotImplementedError("savefig")


def refresh(*args):
    raise NotImplementedError("refresh")


def saveFigure(*args):
    raise NotImplementedError("saveFigure")


def uimenu(*args):
    raise NotImplementedError("uimenu")


def ishghandle(*args):
    raise NotImplementedError("ishghandle")


def printtemplate(*args):
    raise NotImplementedError("printtemplate")


def cla(*args):
    raise NotImplementedError("cla")


def hgclose(*args):
    raise NotImplementedError("hgclose")


def getFigureToolManager(*args):
    raise NotImplementedError("getFigureToolManager")


def nodither(*args):
    raise NotImplementedError("nodither")


def hggetdisp(*args):
    raise NotImplementedError("hggetdisp")


def figure(*args):
    raise NotImplementedError("figure")


def close(*args):
    logger.warning('NotImplementedError("format")')
    return 1


def gcf(*args):
    raise NotImplementedError("gcf")


def isgraphics(*args):
    raise NotImplementedError("isgraphics")


def printjob(*args):
    raise NotImplementedError("printjob")


def figureToolbarCreateFcn(*args):
    raise NotImplementedError("figureToolbarCreateFcn")


def hgfeval(*args):
    raise NotImplementedError("hgfeval")


def hgsetdisp(*args):
    raise NotImplementedError("hgsetdisp")


def noanimate(*args):
    raise NotImplementedError("noanimate")


def axescheck(*args):
    raise NotImplementedError("axescheck")


def light(*args):
    raise NotImplementedError("light")


def surface(*args):
    raise NotImplementedError("surface")


def isappdata(*args):
    raise NotImplementedError("isappdata")


def ancestor(*args):
    raise NotImplementedError("ancestor")


def defaulterrorcallback(*args):
    raise NotImplementedError("defaulterrorcallback")


def opengl(*args):
    raise NotImplementedError("opengl")


def setprinttemplate(*args):
    raise NotImplementedError("setprinttemplate")


def regionpicker(*args):
    raise NotImplementedError("regionpicker")


def getprinttemplate(*args):
    raise NotImplementedError("getprinttemplate")


def datetickstr(*args):
    raise NotImplementedError("datetickstr")


def is2D(*args):
    raise NotImplementedError("is2D")


def clf(*args):
    raise NotImplementedError("clf")


def groot(*args):
    raise NotImplementedError("groot")


def printdmfile(*args):
    raise NotImplementedError("printdmfile")


def gca(*args):
    raise NotImplementedError("gca")


def gco(*args):
    raise NotImplementedError("gco")


def openfig(*args):
    raise NotImplementedError("openfig")


def hgtransform(*args):
    raise NotImplementedError("hgtransform")


def tex(*args):
    raise NotImplementedError("tex")


def datachildren(*args):
    raise NotImplementedError("datachildren")


def struct2handle(*args):
    raise NotImplementedError("struct2handle")


def orient(*args):
    raise NotImplementedError("orient")


def hold(*args):
    raise NotImplementedError("hold")


def graphicsversion(*args):
    raise NotImplementedError("graphicsversion")


def printpreview(*args):
    raise NotImplementedError("printpreview")
