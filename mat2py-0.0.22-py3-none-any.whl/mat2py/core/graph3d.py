# type: ignore

__all__ = [
    "specular",
    "white",
    "cmunique",
    "ylim",
    "cmpermute",
    "lightangle",
    "xlim",
    "camorbit",
    "copper",
    "camzoom",
    "caxis",
    "daspect",
    "alim",
    "viewmtx",
    "hsv",
    "surfl",
    "autumn",
    "camlookat",
    "winter",
    "rotate3d",
    "summer",
    "colormap",
    "spring",
    "imapprox",
    "colorcube",
    "graymon",
    "plot3",
    "campan",
    "lighting",
    "whitebg",
    "fill3",
    "camup",
    "cameramenu",
    "gray",
    "lines",
    "jet",
    "surf",
    "diffuse",
    "camroll",
    "shading",
    "bone",
    "objbounds",
    "parula",
    "camlight",
    "cmapeditor",
    "colordef",
    "camdolly",
    "colormapeditor",
    "flag",
    "material",
    "camtarget",
    "camrotate",
    "campos",
    "hot",
    "alpha",
    "cameratoolbar",
    "hidden",
    "pbaspect",
    "cool",
    "zlim",
    "mesh",
    "brighten",
    "prism",
    "view",
    "zlabel",
    "camproj",
    "pink",
    "surfnorm",
    "alphamap",
    "vga",
    "camva",
]


def specular(*args):
    raise NotImplementedError("specular")


def white(*args):
    raise NotImplementedError("white")


def cmunique(*args):
    raise NotImplementedError("cmunique")


def ylim(*args):
    raise NotImplementedError("ylim")


def cmpermute(*args):
    raise NotImplementedError("cmpermute")


def lightangle(*args):
    raise NotImplementedError("lightangle")


def xlim(*args):
    raise NotImplementedError("xlim")


def camorbit(*args):
    raise NotImplementedError("camorbit")


def copper(*args):
    raise NotImplementedError("copper")


def camzoom(*args):
    raise NotImplementedError("camzoom")


def caxis(*args):
    raise NotImplementedError("caxis")


def daspect(*args):
    raise NotImplementedError("daspect")


def alim(*args):
    raise NotImplementedError("alim")


def viewmtx(*args):
    raise NotImplementedError("viewmtx")


def hsv(*args):
    raise NotImplementedError("hsv")


def surfl(*args):
    raise NotImplementedError("surfl")


def autumn(*args):
    raise NotImplementedError("autumn")


def camlookat(*args):
    raise NotImplementedError("camlookat")


def winter(*args):
    raise NotImplementedError("winter")


def rotate3d(*args):
    raise NotImplementedError("rotate3d")


def summer(*args):
    raise NotImplementedError("summer")


def colormap(*args):
    raise NotImplementedError("colormap")


def spring(*args):
    raise NotImplementedError("spring")


def imapprox(*args):
    raise NotImplementedError("imapprox")


def colorcube(*args):
    raise NotImplementedError("colorcube")


def graymon(*args):
    raise NotImplementedError("graymon")


def plot3(*args):
    raise NotImplementedError("plot3")


def campan(*args):
    raise NotImplementedError("campan")


def lighting(*args):
    raise NotImplementedError("lighting")


def whitebg(*args):
    raise NotImplementedError("whitebg")


def fill3(*args):
    raise NotImplementedError("fill3")


def camup(*args):
    raise NotImplementedError("camup")


def cameramenu(*args):
    raise NotImplementedError("cameramenu")


def gray(*args):
    raise NotImplementedError("gray")


def lines(*args):
    raise NotImplementedError("lines")


def jet(*args):
    raise NotImplementedError("jet")


def surf(*args):
    raise NotImplementedError("surf")


def diffuse(*args):
    raise NotImplementedError("diffuse")


def camroll(*args):
    raise NotImplementedError("camroll")


def shading(*args):
    raise NotImplementedError("shading")


def bone(*args):
    raise NotImplementedError("bone")


def objbounds(*args):
    raise NotImplementedError("objbounds")


def parula(*args):
    raise NotImplementedError("parula")


def camlight(*args):
    raise NotImplementedError("camlight")


def cmapeditor(*args):
    raise NotImplementedError("cmapeditor")


def colordef(*args):
    raise NotImplementedError("colordef")


def camdolly(*args):
    raise NotImplementedError("camdolly")


def colormapeditor(*args):
    raise NotImplementedError("colormapeditor")


def flag(*args):
    raise NotImplementedError("flag")


def material(*args):
    raise NotImplementedError("material")


def camtarget(*args):
    raise NotImplementedError("camtarget")


def camrotate(*args):
    raise NotImplementedError("camrotate")


def campos(*args):
    raise NotImplementedError("campos")


def hot(*args):
    raise NotImplementedError("hot")


def alpha(*args):
    raise NotImplementedError("alpha")


def cameratoolbar(*args):
    raise NotImplementedError("cameratoolbar")


def hidden(*args):
    raise NotImplementedError("hidden")


def pbaspect(*args):
    raise NotImplementedError("pbaspect")


def cool(*args):
    raise NotImplementedError("cool")


def zlim(*args):
    raise NotImplementedError("zlim")


def mesh(*args):
    raise NotImplementedError("mesh")


def brighten(*args):
    raise NotImplementedError("brighten")


def prism(*args):
    raise NotImplementedError("prism")


def view(*args):
    raise NotImplementedError("view")


def zlabel(*args):
    raise NotImplementedError("zlabel")


def camproj(*args):
    raise NotImplementedError("camproj")


def pink(*args):
    raise NotImplementedError("pink")


def surfnorm(*args):
    raise NotImplementedError("surfnorm")


def alphamap(*args):
    raise NotImplementedError("alphamap")


def vga(*args):
    raise NotImplementedError("vga")


def camva(*args):
    raise NotImplementedError("camva")
