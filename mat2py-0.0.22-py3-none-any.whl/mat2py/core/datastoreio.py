# type: ignore

__all__ = [
    "readDatastoreImage",
    "datastore",
]


def readDatastoreImage(*args):
    raise NotImplementedError("readDatastoreImage")


def datastore(*args):
    raise NotImplementedError("datastore")
