# type: ignore

__all__ = [
    "functiontests",
    "runtests",
]


def functiontests(*args):
    raise NotImplementedError("functiontests")


def runtests(*args):
    raise NotImplementedError("runtests")
