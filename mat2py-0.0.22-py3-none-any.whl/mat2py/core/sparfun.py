# type: ignore

__all__ = [
    "sprank",
    "spfun",
    "issparse",
    "nzmax",
    "treelayout",
    "colamd",
    "etreeplot",
    "gplot",
    "unmesh",
    "spones",
    "spdiags",
    "spalloc",
    "numgrid",
    "gmres",
    "treeplot",
    "sparse",
    "speye",
    "bicgstabl",
    "pcg",
    "symmlq",
    "full",
    "amd",
    "bicgstab",
    "eigs",
    "spparms",
    "etree",
    "qmr",
    "spy",
    "minres",
    "nested",
    "delsq",
    "rjr",
    "spconvert",
    "spaugment",
    "sprandsym",
    "svds",
    "lsqr",
    "tfqmr",
    "ichol",
    "bicg",
    "symbfact",
    "symrcm",
    "cgs",
    "nnz",
    "sprand",
    "nonzeros",
    "symamd",
    "sprandn",
    "colperm",
    "ilu",
    "dmperm",
]


def sprank(*args):
    raise NotImplementedError("sprank")


def spfun(*args):
    raise NotImplementedError("spfun")


def issparse(*args):
    raise NotImplementedError("issparse")


def nzmax(*args):
    raise NotImplementedError("nzmax")


def treelayout(*args):
    raise NotImplementedError("treelayout")


def colamd(*args):
    raise NotImplementedError("colamd")


def etreeplot(*args):
    raise NotImplementedError("etreeplot")


def gplot(*args):
    raise NotImplementedError("gplot")


def unmesh(*args):
    raise NotImplementedError("unmesh")


def spones(*args):
    raise NotImplementedError("spones")


def spdiags(*args):
    raise NotImplementedError("spdiags")


def spalloc(*args):
    raise NotImplementedError("spalloc")


def numgrid(*args):
    raise NotImplementedError("numgrid")


def gmres(*args):
    raise NotImplementedError("gmres")


def treeplot(*args):
    raise NotImplementedError("treeplot")


def sparse(*args):
    raise NotImplementedError("sparse")


def speye(*args):
    raise NotImplementedError("speye")


def bicgstabl(*args):
    raise NotImplementedError("bicgstabl")


def pcg(*args):
    raise NotImplementedError("pcg")


def symmlq(*args):
    raise NotImplementedError("symmlq")


def full(*args):
    raise NotImplementedError("full")


def amd(*args):
    raise NotImplementedError("amd")


def bicgstab(*args):
    raise NotImplementedError("bicgstab")


def eigs(*args):
    raise NotImplementedError("eigs")


def spparms(*args):
    raise NotImplementedError("spparms")


def etree(*args):
    raise NotImplementedError("etree")


def qmr(*args):
    raise NotImplementedError("qmr")


def spy(*args):
    raise NotImplementedError("spy")


def minres(*args):
    raise NotImplementedError("minres")


def nested(*args):
    raise NotImplementedError("nested")


def delsq(*args):
    raise NotImplementedError("delsq")


def rjr(*args):
    raise NotImplementedError("rjr")


def spconvert(*args):
    raise NotImplementedError("spconvert")


def spaugment(*args):
    raise NotImplementedError("spaugment")


def sprandsym(*args):
    raise NotImplementedError("sprandsym")


def svds(*args):
    raise NotImplementedError("svds")


def lsqr(*args):
    raise NotImplementedError("lsqr")


def tfqmr(*args):
    raise NotImplementedError("tfqmr")


def ichol(*args):
    raise NotImplementedError("ichol")


def bicg(*args):
    raise NotImplementedError("bicg")


def symbfact(*args):
    raise NotImplementedError("symbfact")


def symrcm(*args):
    raise NotImplementedError("symrcm")


def cgs(*args):
    raise NotImplementedError("cgs")


def nnz(*args):
    raise NotImplementedError("nnz")


def sprand(*args):
    raise NotImplementedError("sprand")


def nonzeros(*args):
    raise NotImplementedError("nonzeros")


def symamd(*args):
    raise NotImplementedError("symamd")


def sprandn(*args):
    raise NotImplementedError("sprandn")


def colperm(*args):
    raise NotImplementedError("colperm")


def ilu(*args):
    raise NotImplementedError("ilu")


def dmperm(*args):
    raise NotImplementedError("dmperm")
