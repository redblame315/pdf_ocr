# type: ignore

__all__ = [
    "ddeunadv",
    "eventlisteners",
    "sampev",
    "regmatlabserver",
    "ddereq",
    "ddepoke",
    "winqueryreg",
    "ddeadv",
    "changeNotificationAdvanced",
    "registerevent",
    "unregisterallevents",
    "unregisterevent",
    "actxcontrolcreateproperty",
    "ddeexec",
    "mwsamp",
    "actxGetRunningServer",
    "actxcontrolselect",
    "changeNotification",
    "ddeterm",
    "actxcontrollist",
    "actxserver",
    "enableservice",
    "writeactxlicense",
    "ddeinit",
    "winopen",
    "isevent",
]


def ddeunadv(*args):
    raise NotImplementedError("ddeunadv")


def eventlisteners(*args):
    raise NotImplementedError("eventlisteners")


def sampev(*args):
    raise NotImplementedError("sampev")


def regmatlabserver(*args):
    raise NotImplementedError("regmatlabserver")


def ddereq(*args):
    raise NotImplementedError("ddereq")


def ddepoke(*args):
    raise NotImplementedError("ddepoke")


def winqueryreg(*args):
    raise NotImplementedError("winqueryreg")


def ddeadv(*args):
    raise NotImplementedError("ddeadv")


def changeNotificationAdvanced(*args):
    raise NotImplementedError("changeNotificationAdvanced")


def registerevent(*args):
    raise NotImplementedError("registerevent")


def unregisterallevents(*args):
    raise NotImplementedError("unregisterallevents")


def unregisterevent(*args):
    raise NotImplementedError("unregisterevent")


def actxcontrolcreateproperty(*args):
    raise NotImplementedError("actxcontrolcreateproperty")


def ddeexec(*args):
    raise NotImplementedError("ddeexec")


def mwsamp(*args):
    raise NotImplementedError("mwsamp")


def actxGetRunningServer(*args):
    raise NotImplementedError("actxGetRunningServer")


def actxcontrolselect(*args):
    raise NotImplementedError("actxcontrolselect")


def changeNotification(*args):
    raise NotImplementedError("changeNotification")


def ddeterm(*args):
    raise NotImplementedError("ddeterm")


def actxcontrollist(*args):
    raise NotImplementedError("actxcontrollist")


def actxserver(*args):
    raise NotImplementedError("actxserver")


def enableservice(*args):
    raise NotImplementedError("enableservice")


def writeactxlicense(*args):
    raise NotImplementedError("writeactxlicense")


def ddeinit(*args):
    raise NotImplementedError("ddeinit")


def winopen(*args):
    raise NotImplementedError("winopen")


def isevent(*args):
    raise NotImplementedError("isevent")
