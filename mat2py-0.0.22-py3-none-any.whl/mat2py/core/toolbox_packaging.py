# type: ignore

__all__ = [
    "mltbxfinfo",
]


def mltbxfinfo(*args):
    raise NotImplementedError("mltbxfinfo")
