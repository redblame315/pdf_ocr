# type: ignore

__all__ = [
    "webcamlist",
    "webcam",
]


def webcamlist(*args):
    raise NotImplementedError("webcamlist")


def webcam(*args):
    raise NotImplementedError("webcam")
