# type: ignore

__all__ = [
    "tsnewevent",
    "tsnansum",
    "tsprctile",
    "simulinkts2ts",
    "tsdateinterval",
    "tsIsDateFormat",
    "uttsget",
    "tsnanmax",
    "tsunitconv",
    "tssorttime",
    "tsIsSameTime",
    "tsAlignSizes",
    "tsChkTime",
    "tsnanstd",
    "tsnanmedian",
    "tsgetDateFormat",
    "tspnmatch",
    "tspvformat",
    "tsarrayFcn",
    "tsnanmean",
    "tsinterp",
    "tsnaniqr",
    "tsAnalyzeAbsTime",
    "utTrimNans",
    "tsnanmin",
    "tsnanmode",
    "tsgetrelativetime",
    "tsnanvar",
]


def tsnewevent(*args):
    raise NotImplementedError("tsnewevent")


def tsnansum(*args):
    raise NotImplementedError("tsnansum")


def tsprctile(*args):
    raise NotImplementedError("tsprctile")


def simulinkts2ts(*args):
    raise NotImplementedError("simulinkts2ts")


def tsdateinterval(*args):
    raise NotImplementedError("tsdateinterval")


def tsIsDateFormat(*args):
    raise NotImplementedError("tsIsDateFormat")


def uttsget(*args):
    raise NotImplementedError("uttsget")


def tsnanmax(*args):
    raise NotImplementedError("tsnanmax")


def tsunitconv(*args):
    raise NotImplementedError("tsunitconv")


def tssorttime(*args):
    raise NotImplementedError("tssorttime")


def tsIsSameTime(*args):
    raise NotImplementedError("tsIsSameTime")


def tsAlignSizes(*args):
    raise NotImplementedError("tsAlignSizes")


def tsChkTime(*args):
    raise NotImplementedError("tsChkTime")


def tsnanstd(*args):
    raise NotImplementedError("tsnanstd")


def tsnanmedian(*args):
    raise NotImplementedError("tsnanmedian")


def tsgetDateFormat(*args):
    raise NotImplementedError("tsgetDateFormat")


def tspnmatch(*args):
    raise NotImplementedError("tspnmatch")


def tspvformat(*args):
    raise NotImplementedError("tspvformat")


def tsarrayFcn(*args):
    raise NotImplementedError("tsarrayFcn")


def tsnanmean(*args):
    raise NotImplementedError("tsnanmean")


def tsinterp(*args):
    raise NotImplementedError("tsinterp")


def tsnaniqr(*args):
    raise NotImplementedError("tsnaniqr")


def tsAnalyzeAbsTime(*args):
    raise NotImplementedError("tsAnalyzeAbsTime")


def utTrimNans(*args):
    raise NotImplementedError("utTrimNans")


def tsnanmin(*args):
    raise NotImplementedError("tsnanmin")


def tsnanmode(*args):
    raise NotImplementedError("tsnanmode")


def tsgetrelativetime(*args):
    raise NotImplementedError("tsgetrelativetime")


def tsnanvar(*args):
    raise NotImplementedError("tsnanvar")
