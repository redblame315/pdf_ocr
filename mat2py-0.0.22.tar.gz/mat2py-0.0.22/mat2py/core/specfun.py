# type: ignore

__all__ = [
    "pol2cart",
    "rats",
    "erfcx",
    "gcd",
    "besselk",
    "erfc",
    "cart2sph",
    "factor",
    "dot",
    "gamma",
    "erf",
    "erfinv",
    "gammaincinv",
    "bessely",
    "betaln",
    "ellipke",
    "airy",
    "besselh",
    "gammainc",
    "betaincinv",
    "gammaln",
    "rat",
    "lcm",
    "expint",
    "nchoosek",
    "factorial",
    "besseli",
    "sph2cart",
    "betainc",
    "perms",
    "beta",
    "legendre",
    "cross",
    "erfcinv",
    "primes",
    "besselj",
    "psi",
    "cart2pol",
    "isprime",
    "ellipj",
]


def pol2cart(*args):
    raise NotImplementedError("pol2cart")


def rats(*args):
    raise NotImplementedError("rats")


def erfcx(*args):
    raise NotImplementedError("erfcx")


def gcd(*args):
    raise NotImplementedError("gcd")


def besselk(*args):
    raise NotImplementedError("besselk")


def erfc(*args):
    raise NotImplementedError("erfc")


def cart2sph(*args):
    raise NotImplementedError("cart2sph")


def factor(*args):
    raise NotImplementedError("factor")


def dot(*args):
    raise NotImplementedError("dot")


def gamma(*args):
    raise NotImplementedError("gamma")


def erf(*args):
    raise NotImplementedError("erf")


def erfinv(*args):
    raise NotImplementedError("erfinv")


def gammaincinv(*args):
    raise NotImplementedError("gammaincinv")


def bessely(*args):
    raise NotImplementedError("bessely")


def betaln(*args):
    raise NotImplementedError("betaln")


def ellipke(*args):
    raise NotImplementedError("ellipke")


def airy(*args):
    raise NotImplementedError("airy")


def besselh(*args):
    raise NotImplementedError("besselh")


def gammainc(*args):
    raise NotImplementedError("gammainc")


def betaincinv(*args):
    raise NotImplementedError("betaincinv")


def gammaln(*args):
    raise NotImplementedError("gammaln")


def rat(*args):
    raise NotImplementedError("rat")


def lcm(*args):
    raise NotImplementedError("lcm")


def expint(*args):
    raise NotImplementedError("expint")


def nchoosek(*args):
    raise NotImplementedError("nchoosek")


def factorial(*args):
    raise NotImplementedError("factorial")


def besseli(*args):
    raise NotImplementedError("besseli")


def sph2cart(*args):
    raise NotImplementedError("sph2cart")


def betainc(*args):
    raise NotImplementedError("betainc")


def perms(*args):
    raise NotImplementedError("perms")


def beta(*args):
    raise NotImplementedError("beta")


def legendre(*args):
    raise NotImplementedError("legendre")


def cross(*args):
    raise NotImplementedError("cross")


def erfcinv(*args):
    raise NotImplementedError("erfcinv")


def primes(*args):
    raise NotImplementedError("primes")


def besselj(*args):
    raise NotImplementedError("besselj")


def psi(*args):
    raise NotImplementedError("psi")


def cart2pol(*args):
    raise NotImplementedError("cart2pol")


def isprime(*args):
    raise NotImplementedError("isprime")


def ellipj(*args):
    raise NotImplementedError("ellipj")
