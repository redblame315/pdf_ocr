# type: ignore

__all__ = [
    "hdsGetSize",
    "hdsCatArray",
    "hdsNewArray",
    "hdsReplicateArray",
    "hdsGetSlice",
    "hdsReshapeArray",
    "hdsSetSlice",
]


def hdsGetSize(*args):
    raise NotImplementedError("hdsGetSize")


def hdsCatArray(*args):
    raise NotImplementedError("hdsCatArray")


def hdsNewArray(*args):
    raise NotImplementedError("hdsNewArray")


def hdsReplicateArray(*args):
    raise NotImplementedError("hdsReplicateArray")


def hdsGetSlice(*args):
    raise NotImplementedError("hdsGetSlice")


def hdsReshapeArray(*args):
    raise NotImplementedError("hdsReshapeArray")


def hdsSetSlice(*args):
    raise NotImplementedError("hdsSetSlice")
