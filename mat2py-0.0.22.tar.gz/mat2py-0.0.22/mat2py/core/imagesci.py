# type: ignore

__all__ = [
    "hdf5write",
    "cdfread",
    "multibandread",
    "hdfhd",
    "fitsinfo",
    "hdfsw",
    "fitswrite",
    "hdftool",
    "hdfvs",
    "fitsread",
    "hdfhx",
    "cdfinfo",
    "h5readatt",
    "exifread",
    "hdfvh",
    "hdfdfr8",
    "ncwrite",
    "hdfinfo",
    "hdfv",
    "ncdisp",
    "hdf5info",
    "h5info",
    "imformats",
    "hdfvf",
    "h5create",
    "multibandwrite",
    "hdf5read",
    "h5read",
    "hdfread",
    "ncwriteatt",
    "hdfgd",
    "ncinfo",
    "imfinfo",
    "h5disp",
    "hdf",
    "hdf5",
    "imread",
    "h5write",
    "Tiff",
    "ncreadatt",
    "hdfml",
    "nccreate",
    "hdfpt",
    "hdfdf24",
    "ncwriteschema",
    "ncread",
    "hdfan",
    "cdfwrite",
    "h5writeatt",
    "fitsdisp",
    "hdfhe",
    "imwrite",
    "hdfsd",
    "hdfh",
]


def hdf5write(*args):
    raise NotImplementedError("hdf5write")


def cdfread(*args):
    raise NotImplementedError("cdfread")


def multibandread(*args):
    raise NotImplementedError("multibandread")


def hdfhd(*args):
    raise NotImplementedError("hdfhd")


def fitsinfo(*args):
    raise NotImplementedError("fitsinfo")


def hdfsw(*args):
    raise NotImplementedError("hdfsw")


def fitswrite(*args):
    raise NotImplementedError("fitswrite")


def hdftool(*args):
    raise NotImplementedError("hdftool")


def hdfvs(*args):
    raise NotImplementedError("hdfvs")


def fitsread(*args):
    raise NotImplementedError("fitsread")


def hdfhx(*args):
    raise NotImplementedError("hdfhx")


def cdfinfo(*args):
    raise NotImplementedError("cdfinfo")


def h5readatt(*args):
    raise NotImplementedError("h5readatt")


def exifread(*args):
    raise NotImplementedError("exifread")


def hdfvh(*args):
    raise NotImplementedError("hdfvh")


def hdfdfr8(*args):
    raise NotImplementedError("hdfdfr8")


def ncwrite(*args):
    raise NotImplementedError("ncwrite")


def hdfinfo(*args):
    raise NotImplementedError("hdfinfo")


def hdfv(*args):
    raise NotImplementedError("hdfv")


def ncdisp(*args):
    raise NotImplementedError("ncdisp")


def hdf5info(*args):
    raise NotImplementedError("hdf5info")


def h5info(*args):
    raise NotImplementedError("h5info")


def imformats(*args):
    raise NotImplementedError("imformats")


def hdfvf(*args):
    raise NotImplementedError("hdfvf")


def h5create(*args):
    raise NotImplementedError("h5create")


def multibandwrite(*args):
    raise NotImplementedError("multibandwrite")


def hdf5read(*args):
    raise NotImplementedError("hdf5read")


def h5read(*args):
    raise NotImplementedError("h5read")


def hdfread(*args):
    raise NotImplementedError("hdfread")


def ncwriteatt(*args):
    raise NotImplementedError("ncwriteatt")


def hdfgd(*args):
    raise NotImplementedError("hdfgd")


def ncinfo(*args):
    raise NotImplementedError("ncinfo")


def imfinfo(*args):
    raise NotImplementedError("imfinfo")


def h5disp(*args):
    raise NotImplementedError("h5disp")


def hdf(*args):
    raise NotImplementedError("hdf")


def hdf5(*args):
    raise NotImplementedError("hdf5")


def imread(*args):
    raise NotImplementedError("imread")


def h5write(*args):
    raise NotImplementedError("h5write")


def Tiff(*args):
    raise NotImplementedError("Tiff")


def ncreadatt(*args):
    raise NotImplementedError("ncreadatt")


def hdfml(*args):
    raise NotImplementedError("hdfml")


def nccreate(*args):
    raise NotImplementedError("nccreate")


def hdfpt(*args):
    raise NotImplementedError("hdfpt")


def hdfdf24(*args):
    raise NotImplementedError("hdfdf24")


def ncwriteschema(*args):
    raise NotImplementedError("ncwriteschema")


def ncread(*args):
    raise NotImplementedError("ncread")


def hdfan(*args):
    raise NotImplementedError("hdfan")


def cdfwrite(*args):
    raise NotImplementedError("cdfwrite")


def h5writeatt(*args):
    raise NotImplementedError("h5writeatt")


def fitsdisp(*args):
    raise NotImplementedError("fitsdisp")


def hdfhe(*args):
    raise NotImplementedError("hdfhe")


def imwrite(*args):
    raise NotImplementedError("imwrite")


def hdfsd(*args):
    raise NotImplementedError("hdfsd")


def hdfh(*args):
    raise NotImplementedError("hdfh")
