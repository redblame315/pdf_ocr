# type: ignore

__all__ = [
    "demos",
    "whatsnew",
    "showdemo",
    "indexhelper",
    "docroot",
    "builddocsearchdb",
    "helpdesk",
    "helpbrowser",
    "info",
    "helpwin",
    "support",
    "web",
    "playshow",
    "echodemo",
    "playbackdemo",
    "lookfor",
    "help",
    "demowin",
    "helpPopup",
    "docsearch",
    "displayEndOfDemoMessage",
    "demo",
    "doc",
    "helpview",
    "help2html",
    "docpath",
]


def demos(*args):
    raise NotImplementedError("demos")


def whatsnew(*args):
    raise NotImplementedError("whatsnew")


def showdemo(*args):
    raise NotImplementedError("showdemo")


def indexhelper(*args):
    raise NotImplementedError("indexhelper")


def docroot(*args):
    raise NotImplementedError("docroot")


def builddocsearchdb(*args):
    raise NotImplementedError("builddocsearchdb")


def helpdesk(*args):
    raise NotImplementedError("helpdesk")


def helpbrowser(*args):
    raise NotImplementedError("helpbrowser")


def info(*args):
    raise NotImplementedError("info")


def helpwin(*args):
    raise NotImplementedError("helpwin")


def support(*args):
    raise NotImplementedError("support")


def web(*args):
    raise NotImplementedError("web")


def playshow(*args):
    raise NotImplementedError("playshow")


def echodemo(*args):
    raise NotImplementedError("echodemo")


def playbackdemo(*args):
    raise NotImplementedError("playbackdemo")


def lookfor(*args):
    raise NotImplementedError("lookfor")


def help(*args):
    raise NotImplementedError("help")


def demowin(*args):
    raise NotImplementedError("demowin")


def helpPopup(*args):
    raise NotImplementedError("helpPopup")


def docsearch(*args):
    raise NotImplementedError("docsearch")


def displayEndOfDemoMessage(*args):
    raise NotImplementedError("displayEndOfDemoMessage")


def demo(*args):
    raise NotImplementedError("demo")


def doc(*args):
    raise NotImplementedError("doc")


def helpview(*args):
    raise NotImplementedError("helpview")


def help2html(*args):
    raise NotImplementedError("help2html")


def docpath(*args):
    raise NotImplementedError("docpath")
