# type: ignore

__all__ = [
    "lin2mu",
    "wavfinfo",
    "avifinfo",
    "audiorecorderreg",
    "mu2lin",
    "wavread",
    "soundsc",
    "audiowrite",
    "prefspanel",
    "audiouniquename",
    "wavwrite",
    "sound",
    "aufinfo",
    "aviinfo",
    "auread",
    "audioplayerreg",
    "avgate",
    "auwrite",
    "audioread",
    "audiodevinfo",
    "mmcompinfo",
    "mmfileinfo",
    "movie2avi",
    "audioinfo",
]


def lin2mu(*args):
    raise NotImplementedError("lin2mu")


def wavfinfo(*args):
    raise NotImplementedError("wavfinfo")


def avifinfo(*args):
    raise NotImplementedError("avifinfo")


def audiorecorderreg(*args):
    raise NotImplementedError("audiorecorderreg")


def mu2lin(*args):
    raise NotImplementedError("mu2lin")


def wavread(*args):
    raise NotImplementedError("wavread")


def soundsc(*args):
    raise NotImplementedError("soundsc")


def audiowrite(*args):
    raise NotImplementedError("audiowrite")


def prefspanel(*args):
    raise NotImplementedError("prefspanel")


def audiouniquename(*args):
    raise NotImplementedError("audiouniquename")


def wavwrite(*args):
    raise NotImplementedError("wavwrite")


def sound(*args):
    raise NotImplementedError("sound")


def aufinfo(*args):
    raise NotImplementedError("aufinfo")


def aviinfo(*args):
    raise NotImplementedError("aviinfo")


def auread(*args):
    raise NotImplementedError("auread")


def audioplayerreg(*args):
    raise NotImplementedError("audioplayerreg")


def avgate(*args):
    raise NotImplementedError("avgate")


def auwrite(*args):
    raise NotImplementedError("auwrite")


def audioread(*args):
    raise NotImplementedError("audioread")


def audiodevinfo(*args):
    raise NotImplementedError("audiodevinfo")


def mmcompinfo(*args):
    raise NotImplementedError("mmcompinfo")


def mmfileinfo(*args):
    raise NotImplementedError("mmfileinfo")


def movie2avi(*args):
    raise NotImplementedError("movie2avi")


def audioinfo(*args):
    raise NotImplementedError("audioinfo")
