# type: ignore

__all__ = [
    "integral3",
    "vectorize",
    "triplequad",
    "ode23t",
    "quadv",
    "odextend",
    "ddesd",
    "ode113",
    "odephas3",
    "dde23",
    "bvpset",
    "odeset",
    "fcnchk",
    "ode15i",
    "bvpget",
    "odeget",
    "ode23s",
    "odeplot",
    "symvar",
    "integral",
    "ode23tb",
    "bvpxtend",
    "bvp4c",
    "pdepe",
    "decic",
    "quadgk",
    "quad2d",
    "ode15s",
    "quad",
    "ode23",
    "bvp5c",
    "quadl",
    "ddensd",
    "integral2",
    "dblquad",
    "odeprint",
    "odephas2",
    "deval",
    "pdeval",
    "numjac",
    "ddeset",
    "inlineeval",
    "ode45",
    "bvpinit",
    "ddeget",
]


def integral3(*args):
    raise NotImplementedError("integral3")


def vectorize(*args):
    raise NotImplementedError("vectorize")


def triplequad(*args):
    raise NotImplementedError("triplequad")


def ode23t(*args):
    raise NotImplementedError("ode23t")


def quadv(*args):
    raise NotImplementedError("quadv")


def odextend(*args):
    raise NotImplementedError("odextend")


def ddesd(*args):
    raise NotImplementedError("ddesd")


def ode113(*args):
    raise NotImplementedError("ode113")


def odephas3(*args):
    raise NotImplementedError("odephas3")


def dde23(*args):
    raise NotImplementedError("dde23")


def bvpset(*args):
    raise NotImplementedError("bvpset")


def odeset(*args):
    raise NotImplementedError("odeset")


def fcnchk(*args):
    raise NotImplementedError("fcnchk")


def ode15i(*args):
    raise NotImplementedError("ode15i")


def bvpget(*args):
    raise NotImplementedError("bvpget")


def odeget(*args):
    raise NotImplementedError("odeget")


def ode23s(*args):
    raise NotImplementedError("ode23s")


def odeplot(*args):
    raise NotImplementedError("odeplot")


def symvar(*args):
    raise NotImplementedError("symvar")


def integral(*args):
    raise NotImplementedError("integral")


def ode23tb(*args):
    raise NotImplementedError("ode23tb")


def bvpxtend(*args):
    raise NotImplementedError("bvpxtend")


def bvp4c(*args):
    raise NotImplementedError("bvp4c")


def pdepe(*args):
    raise NotImplementedError("pdepe")


def decic(*args):
    raise NotImplementedError("decic")


def quadgk(*args):
    raise NotImplementedError("quadgk")


def quad2d(*args):
    raise NotImplementedError("quad2d")


def ode15s(*args):
    raise NotImplementedError("ode15s")


def quad(*args):
    raise NotImplementedError("quad")


def ode23(*args):
    raise NotImplementedError("ode23")


def bvp5c(*args):
    raise NotImplementedError("bvp5c")


def quadl(*args):
    raise NotImplementedError("quadl")


def ddensd(*args):
    raise NotImplementedError("ddensd")


def integral2(*args):
    raise NotImplementedError("integral2")


def dblquad(*args):
    raise NotImplementedError("dblquad")


def odeprint(*args):
    raise NotImplementedError("odeprint")


def odephas2(*args):
    raise NotImplementedError("odephas2")


def deval(*args):
    raise NotImplementedError("deval")


def pdeval(*args):
    raise NotImplementedError("pdeval")


def numjac(*args):
    raise NotImplementedError("numjac")


def ddeset(*args):
    raise NotImplementedError("ddeset")


def inlineeval(*args):
    raise NotImplementedError("inlineeval")


def ode45(*args):
    raise NotImplementedError("ode45")


def bvpinit(*args):
    raise NotImplementedError("bvpinit")


def ddeget(*args):
    raise NotImplementedError("ddeget")
